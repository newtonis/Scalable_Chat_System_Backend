import psycopg2
import psycopg2.extras
from psycopg2 import DatabaseError

from dotenv import load_dotenv
import os
from .database_conn import database_conn
import logging


def try_init_database():    
    conn = database_conn.conn
    cursor = database_conn.cursor

    command = """
        SELECT exists (
            SELECT FROM information_schema.tables 
                WHERE  table_schema = 'public' -- O el nombre de tu esquema
                AND    table_name   = 'message_groups'
        )
    """

    cursor.execute(
        command
    )

    fila = cursor.fetchone()
    conn.commit() # Cerramos la transaccion


    if fila[0] != True:
        logging.info("Generating data model for message groups")
        command = """
            CREATE TABLE message_groups 
                (
                    message_group_name VARCHAR(50),
                    counter INTEGER,
                    created_at TIME,
                    updated_at TIME
                )
        """

        cursor.execute(
            command
        )

        # Commit the transactions
        try:
            conn.commit()
            logging.info("Transaction completed")
        except DatabaseError as e:
            conn.rollback() # Closing the transaction
            logging.info("Transaction in conflict, cancelled")

    else:
        logging.info("Data model already generated")


    command = """
        SELECT exists (
            SELECT FROM information_schema.tables 
                WHERE  table_schema = 'public' -- O el nombre de tu esquema
                AND    table_name   = 'message_groups'
        )
    """

    cursor.execute(
        command
    )

    fila = cursor.fetchone()
    conn.commit() # Closing transaction

    if fila[0] != True:
        logging.info("Generating data model for message_groups")
        command = """
            CREATE TABLE ecobici_landing_work_queue(
                message_group_name VARCHAR(50),
                counter INTEGER,
                created_at TIME,
                updated_at TIME
            );
        """
        cursor.execute(
            command
        )
        
        # Commit the transaction
        try:
            conn.commit()
            logging.info("Transaction completed")
        except DatabaseError as e:
            conn.rollback() # We declare a psycopg2 transaction faliure
            logging.info("Transaction in conflict, cancelled")

    else:
        logging.info("Modelo de datos ya generado")

def close_connection():
    logging.info("Ending pg database connection ... ")
    conn = database_conn.conn
    cursor = database_conn.cursor

    cursor.close()
    conn.close()
